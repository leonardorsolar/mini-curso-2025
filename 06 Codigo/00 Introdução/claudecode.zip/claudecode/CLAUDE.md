# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Status

This appears to be a fresh project directory. The codebase structure and development commands will be added to this file as the project evolves.

## Development Setup

*To be populated as the project structure is established*

## Architecture

*To be populated as components and modules are added*

## Common Commands

*To be populated based on the chosen technology stack and build tools*